create table CALCULATION (
    ID int not null auto_increment,
    A varchar(100),
    B varchar(100),
    RESULT varchar(100),
    primary key (ID)
);