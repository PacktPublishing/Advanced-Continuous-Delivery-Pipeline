update CALCULATION
set CALCULATION.sum = CALCULATION.result
where CALCULATION.sum is null;