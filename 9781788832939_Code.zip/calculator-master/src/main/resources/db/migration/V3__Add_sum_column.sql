alter table CALCULATION
add SUM varchar(100);