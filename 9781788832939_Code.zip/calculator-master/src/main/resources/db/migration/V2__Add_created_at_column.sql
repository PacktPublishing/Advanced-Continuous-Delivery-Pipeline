alter table CALCULATION
add CREATED_AT timestamp;