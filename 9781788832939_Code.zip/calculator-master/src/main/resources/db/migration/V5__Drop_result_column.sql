alter table CALCULATION
drop column RESULT;